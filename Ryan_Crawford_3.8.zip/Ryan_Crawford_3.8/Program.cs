﻿/*
 * Name: Ryan Crawford
 * Date: June 1, 2026
 * Purpose: Week 3 Project Submission - Class Implementation.
 * Formalizing the application framework, constructors, and access specifiers 
 * for the RPG Character Vault prior to Week 4 database implementation.
 */

using System;
using System.Collections.Generic;

namespace RPGCharacterVault
{
    // ---------------------------------------------------------
    // INTERFACE DEFINITION
    // ---------------------------------------------------------
    public interface ISpecialAbility
    {
        void ExecuteSpecial();
    }

    // ---------------------------------------------------------
    // COMPONENT CLASS
    // ---------------------------------------------------------
    public class Weapon
    {
        // Access Specifiers: Public read access, Private write access to protect data integrity
        public string ItemName { get; private set; }
        public int DamageRating { get; private set; }

        // Constructor
        public Weapon(string itemName, int damageRating)
        {
            ItemName = itemName;
            DamageRating = damageRating;
        }
    }

    // ---------------------------------------------------------
    // ABSTRACT BASE CLASS
    // ---------------------------------------------------------
    public abstract class Character
    {
        // Protected: Only this class and derived classes (Mage/Warrior) can access/modify this directly
        protected string CharacterName { get; set; }
        
        // Public get, protected set
        public Weapon EquippedWeapon { get; protected set; }

        // Base Constructor
        public Character(string characterName, Weapon weapon)
        {
            CharacterName = characterName;
            EquippedWeapon = weapon;
        }

        // Virtual method allowing polymorphic overriding
        public virtual void DisplayStats()
        {
            Console.WriteLine($"Name: {CharacterName}");
            Console.WriteLine($"Weapon: {EquippedWeapon.ItemName} (+{EquippedWeapon.DamageRating} DMG)");
        }
    }

    // ---------------------------------------------------------
    // DERIVED CLASS: MAGE
    // ---------------------------------------------------------
    public class Mage : Character, ISpecialAbility
    {
        public int TotalMana { get; private set; }

        // Constructor passing base parameters to the base class via ': base()'
        public Mage(string characterName, Weapon weapon, int totalMana) 
            : base(characterName, weapon)
        {
            TotalMana = totalMana;
        }

        // Overriding the virtual method
        public override void DisplayStats()
        {
            base.DisplayStats();
            Console.WriteLine($"Class: Mage | Mana: {TotalMana}");
        }

        public void ExecuteSpecial()
        {
            // Can access CharacterName because it is marked 'protected' in the base class
            Console.WriteLine($"* {CharacterName} casts a devastating Fireball! *");
        }
    }

    // ---------------------------------------------------------
    // DERIVED CLASS: WARRIOR
    // ---------------------------------------------------------
    public class Warrior : Character, ISpecialAbility
    {
        public int ArmorRating { get; private set; }

        public Warrior(string characterName, Weapon weapon, int armorRating) 
            : base(characterName, weapon)
        {
            ArmorRating = armorRating;
        }

        public override void DisplayStats()
        {
            base.DisplayStats();
            Console.WriteLine($"Class: Warrior | Armor Rating: {ArmorRating}");
        }

        public void ExecuteSpecial()
        {
            Console.WriteLine($"* {CharacterName} performs a crushing Shield Bash! *");
        }
    }

    // ---------------------------------------------------------
    // MAIN EXECUTION (FRAMEWORK TEST)
    // ---------------------------------------------------------
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("==================================================");
            Console.WriteLine("Project Phase 1: Class Implementation Framework");
            Console.WriteLine("Developer: Kendrick Antwi");
            Console.WriteLine("==================================================\n");

            // Instantiate components and classes
            Weapon staff = new Weapon("Staff of Magnus", 45);
            Weapon sword = new Weapon("Daedric Greatsword", 65);

            Mage player1 = new Mage("Savos Aren", staff, 450);
            Warrior player2 = new Warrior("Farkas", sword, 120);

            List<Character> roster = new List<Character>() { player1, player2 };

            // Test output to prove classes are functional before database implementation
            Console.WriteLine("--- SYSTEM FRAMEWORK TEST ---");
            foreach (Character c in roster)
            {
                c.DisplayStats();
                if (c is ISpecialAbility abilityUser)
                {
                    abilityUser.ExecuteSpecial();
                }
                Console.WriteLine("-----------------------------");
            }

            Console.WriteLine("\nFramework initialized. Awaiting Week 4 Database integration...");
            Console.ReadKey();
        }
    }
}