﻿/*
 * Name: Ryan Crawford
 * Date: June 9, 2026
 * Purpose: Week 4 Project Submission - Demonstrating database interactions.
 * This application stores the RPG Character Vault data in an SQLite database, 
 * implementing full CRUD (Create, Read, Update, Delete) operations while 
 * maintaining the OOP abstraction, constructors, and access specifiers from Week 3.
 */

using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Data.Sqlite; // Requires the Microsoft.Data.Sqlite NuGet package

namespace RPGCharacterVault
{
    // ---------------------------------------------------------
    // OOP CLASSES (Maintained from Week 3)
    // ---------------------------------------------------------
    
    public class Weapon
    {
        // ACCESS SPECIFIERS: public get, private set ensures encapsulation.
        public int WeaponID { get; set; } // Added for database tracking
        public string ItemName { get; private set; }
        public int DamageRating { get; private set; }

        // CONSTRUCTORS: Overloaded constructors
        public Weapon(string itemName)
        {
            ItemName = itemName;
            DamageRating = 10;
        }

        public Weapon(int id, string itemName, int damageRating)
        {
            WeaponID = id;
            ItemName = itemName;
            DamageRating = damageRating;
        }
    }

    public interface ISpecialAbility
    {
        void ExecuteSpecial();
    }

    // ABSTRACTION: Abstract base class serving as a template.
    public abstract class Character
    {
        public int CharacterID { get; set; } // Added for database tracking
        
        // ACCESS SPECIFIERS: protected allows derived classes to access.
        public string CharacterName { get; protected set; }
        public Weapon EquippedWeapon { get; protected set; }

        public Character(string characterName, Weapon weapon)
        {
            CharacterName = characterName;
            EquippedWeapon = weapon;
        }

        public Character(int id, string characterName, Weapon weapon)
        {
            CharacterID = id;
            CharacterName = characterName;
            EquippedWeapon = weapon;
        }

        public abstract void CalculatePowerLevel();

        public virtual void DisplayStats()
        {
            Console.WriteLine($"ID: [{CharacterID}] | Name: {CharacterName}");
            Console.WriteLine($"Weapon: {EquippedWeapon.ItemName} (+{EquippedWeapon.DamageRating} DMG)");
        }
    }

    public class Mage : Character, ISpecialAbility
    {
        public int TotalMana { get; private set; }

        public Mage(int id, string characterName, Weapon weapon, int totalMana) 
            : base(id, characterName, weapon)
        {
            TotalMana = totalMana;
        }

        public override void CalculatePowerLevel()
        {
            int power = EquippedWeapon.DamageRating + (TotalMana / 10);
            Console.WriteLine($"Power Level (Magic + Weapon): {power}");
        }

        public override void DisplayStats()
        {
            base.DisplayStats();
            Console.WriteLine($"Class: Mage | Mana: {TotalMana}");
            CalculatePowerLevel();
        }

        public void ExecuteSpecial()
        {
            Console.WriteLine($"* {CharacterName} casts a devastating Fireball! *");
        }
    }

    public class Warrior : Character, ISpecialAbility
    {
        public int ArmorRating { get; private set; }

        public Warrior(int id, string characterName, Weapon weapon, int armorRating) 
            : base(id, characterName, weapon)
        {
            ArmorRating = armorRating;
        }

        public override void CalculatePowerLevel()
        {
            int power = EquippedWeapon.DamageRating + (ArmorRating / 5);
            Console.WriteLine($"Power Level (Armor + Weapon): {power}");
        }

        public override void DisplayStats()
        {
            base.DisplayStats();
            Console.WriteLine($"Class: Warrior | Armor Rating: {ArmorRating}");
            CalculatePowerLevel();
        }

        public void ExecuteSpecial()
        {
            Console.WriteLine($"* {CharacterName} performs a crushing Shield Bash! *");
        }
    }

    // ---------------------------------------------------------
    // DATABASE MANAGER (Handling CRUD Operations)
    // ---------------------------------------------------------
    public class DatabaseManager
    {
        private string connectionString = "Data Source=rpg_vault.db";

        // INITIALIZATION: Creates the database file and tables if they don't exist
        public void InitializeDatabase()
        {
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                
                string createWeaponsTable = @"
                    CREATE TABLE IF NOT EXISTS Weapons (
                        WeaponID INTEGER PRIMARY KEY AUTOINCREMENT,
                        ItemName TEXT NOT NULL,
                        DamageRating INTEGER NOT NULL
                    );";
                
                string createCharactersTable = @"
                    CREATE TABLE IF NOT EXISTS Characters (
                        CharacterID INTEGER PRIMARY KEY AUTOINCREMENT,
                        CharacterName TEXT NOT NULL,
                        ClassType TEXT NOT NULL,
                        ClassAttribute INTEGER NOT NULL,
                        WeaponID INTEGER,
                        FOREIGN KEY (WeaponID) REFERENCES Weapons(WeaponID)
                    );";

                using (var command = new SqliteCommand(createWeaponsTable, connection)) command.ExecuteNonQuery();
                using (var command = new SqliteCommand(createCharactersTable, connection)) command.ExecuteNonQuery();
            }
        }

        // CREATE: Add a new weapon and return its generated ID
        public int CreateWeapon(string name, int damage)
        {
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Weapons (ItemName, DamageRating) VALUES (@name, @damage); SELECT last_insert_rowid();";
                using (var command = new SqliteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@name", name);
                    command.Parameters.AddWithValue("@damage", damage);
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        // CREATE: Add a new character
        public void CreateCharacter(string name, string classType, int attribute, int weaponId)
        {
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Characters (CharacterName, ClassType, ClassAttribute, WeaponID) VALUES (@name, @class, @attr, @wid)";
                using (var command = new SqliteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@name", name);
                    command.Parameters.AddWithValue("@class", classType);
                    command.Parameters.AddWithValue("@attr", attribute);
                    command.Parameters.AddWithValue("@wid", weaponId);
                    command.ExecuteNonQuery();
                }
            }
            Console.WriteLine($"[DB] Added new character: {name}");
        }

        // READ: Retrieve all characters and map them back to OOP objects
        public List<Character> ReadAllCharacters()
        {
            List<Character> roster = new List<Character>();
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                string query = @"
                    SELECT c.CharacterID, c.CharacterName, c.ClassType, c.ClassAttribute, 
                           w.WeaponID, w.ItemName, w.DamageRating 
                    FROM Characters c
                    JOIN Weapons w ON c.WeaponID = w.WeaponID";

                using (var command = new SqliteCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int charId = reader.GetInt32(0);
                        string name = reader.GetString(1);
                        string classType = reader.GetString(2);
                        int attribute = reader.GetInt32(3);
                        
                        Weapon w = new Weapon(reader.GetInt32(4), reader.GetString(5), reader.GetInt32(6));

                        if (classType == "Mage")
                        {
                            roster.Add(new Mage(charId, name, w, attribute));
                        }
                        else if (classType == "Warrior")
                        {
                            roster.Add(new Warrior(charId, name, w, attribute));
                        }
                    }
                }
            }
            return roster;
        }

        // UPDATE: Modify a character's specific attribute
        public void UpdateCharacterAttribute(int characterId, int newAttribute)
        {
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                string query = "UPDATE Characters SET ClassAttribute = @attr WHERE CharacterID = @id";
                using (var command = new SqliteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@attr", newAttribute);
                    command.Parameters.AddWithValue("@id", characterId);
                    command.ExecuteNonQuery();
                }
            }
            Console.WriteLine($"[DB] Updated Character ID {characterId} with new stats.");
        }

        // DELETE: Remove a character from the database
        public void DeleteCharacter(int characterId)
        {
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                string query = "DELETE FROM Characters WHERE CharacterID = @id";
                using (var command = new SqliteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@id", characterId);
                    command.ExecuteNonQuery();
                }
            }
            Console.WriteLine($"[DB] Deleted Character ID {characterId} from the vault.");
        }

        // Utility: Clear database for fresh testing
        public void ClearDatabase()
        {
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                using (var cmd = new SqliteCommand("DELETE FROM Characters; DELETE FROM Weapons;", connection))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }

    // ---------------------------------------------------------
    // MAIN EXECUTION
    // ---------------------------------------------------------
    class Program
    {
        static void Main(string[] args)
        {
            // 1. INFORMATIVE INDICATORS
            Console.WriteLine("==================================================");
            Console.WriteLine("Project Week 4: SQLite Database Interactions");
            Console.WriteLine("Developer: Kendrick Antwi");
            Console.WriteLine("==================================================\n");

            // 2. WELCOME MESSAGE & INSTRUCTIONS
            Console.WriteLine("Welcome to the RPG Character Vault Database Manager!");
            Console.WriteLine("This program will demonstrate Create, Read, Update, and Delete (CRUD) operations.");
            Console.WriteLine("Press 'Enter' to initialize the database and begin the simulation...\n");
            Console.ReadLine();

            DatabaseManager db = new DatabaseManager();
            db.InitializeDatabase();
            db.ClearDatabase(); // Clears old test data so the output is clean every time you run it

            // 3. CREATE OPERATION
            Console.WriteLine("--- Executing CREATE Operations ---");
            int staffId = db.CreateWeapon("Staff of Magnus", 45);
            int swordId = db.CreateWeapon("Rusty Iron Sword", 10);
            
            db.CreateCharacter("Savos Aren", "Mage", 450, staffId);
            db.CreateCharacter("Farkas", "Warrior", 120, swordId);
            Console.WriteLine("-----------------------------------\n");

            // 4. READ OPERATION
            Console.WriteLine("--- Executing READ Operation ---");
            List<Character> currentRoster = db.ReadAllCharacters();
            foreach (Character c in currentRoster)
            {
                c.DisplayStats();
                Console.WriteLine();
            }
            Console.WriteLine("--------------------------------\n");

            // 5. UPDATE OPERATION (Targeting the first character in the list)
            if (currentRoster.Count > 0)
            {
                Console.WriteLine("--- Executing UPDATE Operation ---");
                int targetId = currentRoster[0].CharacterID;
                Console.WriteLine($"Leveling up Character ID {targetId}...");
                
                // Simulating a stat increase (e.g., Mage gaining Mana)
                db.UpdateCharacterAttribute(targetId, 600); 
                
                // Read again to prove the update worked
                Character updatedChar = db.ReadAllCharacters().Find(c => c.CharacterID == targetId);
                updatedChar.DisplayStats();
                Console.WriteLine("----------------------------------\n");
            }

            // 6. DELETE OPERATION (Targeting the second character in the list)
            if (currentRoster.Count > 1)
            {
                Console.WriteLine("--- Executing DELETE Operation ---");
                int deleteId = currentRoster[1].CharacterID;
                db.DeleteCharacter(deleteId);

                // Read again to prove they are gone
                Console.WriteLine("\nFinal Roster after Deletion:");
                List<Character> finalRoster = db.ReadAllCharacters();
                foreach (Character c in finalRoster)
                {
                    c.DisplayStats();
                }
                Console.WriteLine("----------------------------------\n");
            }

            Console.WriteLine("Database simulation complete. Press any key to exit.");
            Console.ReadKey();
        }
    }
}